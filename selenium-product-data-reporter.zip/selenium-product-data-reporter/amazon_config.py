from selenium import webdriver
import geckodriver_autoinstaller
from selenium.webdriver.firefox.options import Options

DIRECTORY = 'reports'
NAME = 'mobile'
CURRENCY = '₹'
MIN_PRICE = '10000'
MAX_PRICE = '20000'
FILTERS = {
    'min': MIN_PRICE,
    'max': MAX_PRICE
}

BASE_URL = "http://www.amazon.in/"


def getFirefoxWebDriver(options):
    return webdriver.Firefox(options=options)

def getWebDriverOptions():
    firefox_options = Options()
    # firefox_options.add_argument("--headless") 
    # firefox_options.set_headless(headless=options.headless)

    ffprofile = webdriver.FirefoxProfile()
    firefox_options.profile = ffprofile
    return firefox_options

def setIgnoreCertificateError(options):
    options.accept_insecure_certs = True

def setBrowserAsIncognito(options):
    options.add_argument('--private')

def makeHeadless(options):
    options.headless = True
